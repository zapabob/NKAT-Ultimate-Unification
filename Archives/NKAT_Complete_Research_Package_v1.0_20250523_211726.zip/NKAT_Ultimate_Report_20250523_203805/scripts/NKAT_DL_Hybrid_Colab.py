#!/usr/bin/env python3
"""
🌐 NKAT Deep Learning Hybrid Advanced - Google Colab版
非可換コルモゴロフ-アーノルド表現による究極統一理論
Google Colab最適化版（GPU制限対応・セッション切断対応）

Author: NKAT Research Team
Date: 2025-05-23
Environment: Google Colab (T4/V100/A100対応)
"""

import os
import sys
import time
import json
import pickle
import argparse
import warnings
from datetime import datetime
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm.auto import tqdm

# Google Colab専用インポート
try:
    from google.colab import drive, files
    IN_COLAB = True
    print("🌐 Google Colab環境を検出")
except ImportError:
    IN_COLAB = False
    print("💻 ローカル環境で実行")

# ===================================================================
# 🔧 Google Colab パッケージインストール
# ===================================================================

def install_required_packages():
    """必要パッケージの確実なインストール"""
    
    required_packages = {
        'optuna': 'optuna',
        'psutil': 'psutil',
        'rich': 'rich'
    }
    
    for package_name, pip_name in required_packages.items():
        try:
            __import__(package_name)
            print(f"✅ {package_name} は既にインストール済み")
        except ImportError:
            print(f"📦 {package_name} をインストール中...")
            if IN_COLAB:
                # Google Colabでは!pipを使用
                os.system(f"pip install {pip_name} -q")
            else:
                # ローカル環境
                import subprocess
                subprocess.check_call([sys.executable, "-m", "pip", "install", pip_name])
            
            # インストール後の確認
            try:
                __import__(package_name)
                print(f"✅ {package_name} インストール完了")
            except ImportError:
                print(f"❌ {package_name} インストール失敗")
                if IN_COLAB:
                    print(f"💡 手動実行してください: !pip install {pip_name}")

# パッケージインストール実行
install_required_packages()

# PyTorch関連
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR

# Optuna最適化（インストール後にインポート）
try:
    import optuna
    from optuna.samplers import TPESampler
    from optuna.pruners import MedianPruner
    OPTUNA_AVAILABLE = True
    print("✅ Optuna インポート成功")
except ImportError:
    print("⚠️ Optuna インポート失敗 - 最適化機能は無効")
    OPTUNA_AVAILABLE = False

# psutil（オプション）
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    print("⚠️ psutil インポート失敗 - システム監視機能は無効")
    PSUTIL_AVAILABLE = False

# 警告抑制
warnings.filterwarnings('ignore', category=UserWarning)
warnings.filterwarnings('ignore', category=FutureWarning)

# ===================================================================
# 🌐 Google Colab環境設定
# ===================================================================

def setup_colab_environment():
    """Google Colab環境の初期設定"""
    if not IN_COLAB:
        return
    
    print("🔧 Google Colab環境設定中...")
    
    # Google Driveマウント
    try:
        drive.mount('/content/drive')
        print("📁 Google Driveマウント完了")
        
        # 作業ディレクトリ作成
        work_dir = '/content/drive/MyDrive/NKAT_Research'
        os.makedirs(work_dir, exist_ok=True)
        os.chdir(work_dir)
        print(f"📂 作業ディレクトリ: {work_dir}")
        
    except Exception as e:
        print(f"⚠️ Google Drive接続失敗: {e}")
        print("📂 /contentで作業を継続")
        os.chdir('/content')
    
    # 追加パッケージの確認とインストール
    additional_packages = ['seaborn', 'matplotlib']
    
    for package in additional_packages:
        try:
            __import__(package)
        except ImportError:
            print(f"📦 {package}をインストール中...")
            os.system(f"pip install {package} -q")
    
    # GPU情報表示
    if torch.cuda.is_available():
        gpu_name = torch.cuda.get_device_name(0)
        gpu_memory = torch.cuda.get_device_properties(0).total_memory / 1e9
        print(f"🔥 GPU: {gpu_name}")
        print(f"💾 VRAM: {gpu_memory:.1f} GB")
        
        # Colab GPU最適化
        torch.backends.cudnn.benchmark = True
        if 'A100' in gpu_name or 'V100' in gpu_name:
            torch.backends.cuda.matmul.allow_tf32 = True
            print("⚡ 高性能GPU最適化有効")
    else:
        print("⚠️ GPU未検出 - CPU実行")
    
    # Optuna可用性チェック
    if not OPTUNA_AVAILABLE:
        print("⚠️ Optuna未使用 - ハイパーパラメータ最適化は無効")
        print("💡 手動インストール: !pip install optuna")

# デバイス設定
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
scaler = torch.amp.GradScaler('cuda') if torch.cuda.is_available() else None

# ===================================================================
# ⚙️ Colab最適化設定
# ===================================================================

@dataclass
class ColabNKATConfig:
    """Google Colab最適化 NKAT設定（長期訓練版）"""
    # 物理パラメータ
    theta_base: float = 1e-70
    planck_scale: float = 1.6e-35
    target_spectral_dim: float = 4.0
    spectral_dim_tolerance: float = 0.1
    
    # 🚀 長期訓練最適化設定（ボブにゃん提案版）
    grid_size: int = 64  # 64³ 最高精度グリッド
    batch_size: int = 32  # 最適バッチサイズ
    num_test_functions: int = 256  # 拡張テスト関数
    
    # KAN DL設定（長期訓練版）
    kan_layers: List[int] = field(default_factory=lambda: [4, 512, 256, 128, 4])  # 拡張アーキテクチャ
    learning_rate: float = 1.607e-4  # Optuna最適値
    num_epochs: int = 200  # 長期訓練対応
    
    # 🔥 超長期訓練最適化設定
    n_trials: int = 50  # 拡張Optuna（ボブにゃん提案）
    optuna_quick_epochs: int = 5
    optuna_samples: int = 500  # 拡張サンプリング
    optuna_timeout: int = 600  # 10分制限
    study_name: str = "NKAT_LongTerm_Optimization"
    
    # 🛡️ NaN安全・Early Stopping
    use_mixed_precision: bool = True
    early_stopping_patience: int = 15  # 長期訓練用patience
    early_stopping_min_delta: float = 1e-8  # 高精度閾値
    
    # 物理制約重み（診断結果最適化済み）
    weight_spectral_dim: float = 11.5  # Optuna最適値
    weight_jacobi: float = 1.5
    weight_connes: float = 1.5
    weight_theta_reg: float = 0.1
    weight_running: float = 3.45  # Optuna最適値
    
    # 長期監視設定
    progress_update_freq: int = 10  # 詳細レポート間隔
    gpu_monitoring: bool = True
    save_to_drive: bool = True
    detailed_logging: bool = True
    
    # セッション切断対応（強化版）
    checkpoint_freq: int = 10  # 10エポック毎保存
    auto_backup: bool = True
    resume_from_checkpoint: bool = False
    checkpoint_dir: str = "./nkat_longterm_checkpoints"
    max_checkpoints: int = 20
    emergency_save_interval: int = 10  # 10分間隔
    
    # 🌌 高次元拡張準備
    enable_higher_dimensions: bool = False
    max_dimensions: int = 6
    kappa_minkowski_mode: bool = False

# ===================================================================
# 🧠 KAN Layer (Colab最適化版)
# ===================================================================

class ColabKANLayer(nn.Module):
    """Google Colab最適化 KAN Layer（次元修正版）"""
    
    def __init__(self, input_dim: int, output_dim: int, 
                 grid_size: int = 16, spline_order: int = 3):
        super().__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.grid_size = grid_size
        self.spline_order = spline_order
        
        # 🔧 B-spline次元を正確に計算
        # B-splineの基底関数数は grid_size + spline_order
        self.num_basis = grid_size + spline_order
        
        # Colab メモリ効率重視の重み初期化
        self.base_weight = nn.Parameter(torch.randn(output_dim, input_dim) * 0.1)
        self.spline_weight = nn.Parameter(
            torch.randn(output_dim, input_dim, self.num_basis) * 0.1
        )
        
        # グリッド点（固定、拡張グリッド）
        # spline_orderの分だけ両端を拡張
        extended_grid = torch.linspace(-3, 3, grid_size + 2 * spline_order + 1)
        self.register_buffer('grid', extended_grid)
        
        # 正規化パラメータ
        self.layer_norm = nn.LayerNorm(output_dim)
        self.dropout = nn.Dropout(0.1)
        
        print(f"🔧 KANレイヤー初期化: {input_dim}→{output_dim}, grid={grid_size}, basis={self.num_basis}")
    
    def b_splines(self, x):
        """簡略化B-spline基底関数（ベクトル化版）"""
        batch_size, input_dim = x.shape
        
        # 入力を適切な範囲にクランプ
        x_clamped = torch.clamp(x, self.grid[0], self.grid[-1])
        x_expanded = x_clamped.unsqueeze(-1)  # [batch, input_dim, 1]
        
        # 🔧 簡略化された基底関数計算（ベクトル化）
        # グリッドとの距離を一括計算
        grid_expanded = self.grid.unsqueeze(0).unsqueeze(0)  # [1, 1, grid_points]
        distances = torch.abs(x_expanded - grid_expanded)  # [batch, input, grid_points]
        
        # 基底関数を一括計算（三角形基底）
        # 各グリッド点を中心とした三角形基底関数
        basis_width = 2.0  # 基底関数の幅
        basis_functions = torch.clamp(1 - distances / basis_width, 0, 1)
        
        # 🔧 目標次元に調整
        current_basis_dim = basis_functions.size(-1)
        if current_basis_dim != self.num_basis:
            if current_basis_dim < self.num_basis:
                # パディング
                padding = self.num_basis - current_basis_dim
                basis_functions = F.pad(basis_functions, (0, padding))
            else:
                # トリミング
                basis_functions = basis_functions[:, :, :self.num_basis]
        
        # 正規化（各点での基底関数の和を1にする）
        basis_sum = torch.sum(basis_functions, dim=-1, keepdim=True) + 1e-8
        basis_functions = basis_functions / basis_sum
        
        return basis_functions
    
    def forward(self, x):
        batch_size = x.size(0)
        
        # ベース変換
        base_output = F.linear(x, self.base_weight)
        
        # スプライン変換（改良版）
        spline_basis = self.b_splines(x)  # [batch, input_dim, num_basis]
        
        # 🔧 次元チェックと修正
        basis_batch, basis_input, basis_dim = spline_basis.shape
        weight_output, weight_input, weight_basis = self.spline_weight.shape
        
        # 入力次元の調整
        if basis_input != weight_input:
            if basis_input < weight_input:
                # パディング
                padding = weight_input - basis_input
                spline_basis = F.pad(spline_basis, (0, 0, 0, padding))
            else:
                # トリミング
                spline_basis = spline_basis[:, :weight_input, :]
            basis_input = weight_input
        
        # 基底次元の調整
        if basis_dim != weight_basis:
            if basis_dim < weight_basis:
                # パディング
                padding = weight_basis - basis_dim
                spline_basis = F.pad(spline_basis, (0, padding))
            else:
                # トリミング
                spline_basis = spline_basis[:, :, :weight_basis]
            basis_dim = weight_basis
        
        # 🔧 確実に動作する行列演算による計算（einsum不使用）
        # spline_basis: [batch, input, basis]
        # spline_weight: [output, input, basis]
        # 目標: [batch, output]
        
        # 方法1: フラット化して行列積
        basis_flat = spline_basis.view(batch_size, -1)  # [batch, input*basis]
        weight_flat = self.spline_weight.view(weight_output, -1)  # [output, input*basis]
        spline_output = torch.mm(basis_flat, weight_flat.t())  # [batch, output]
        
        # 結合と正規化
        output = base_output + spline_output
        output = self.layer_norm(output)
        output = self.dropout(output)
        
        return torch.tanh(output)  # 安定化

# ===================================================================
# 🌌 Hybrid NKAT Model (Colab版)
# ===================================================================

class ColabNKATModel(nn.Module):
    """Google Colab最適化 NKAT Model"""
    
    def __init__(self, config: ColabNKATConfig):
        super().__init__()
        self.config = config
        
        # KAN ネットワーク（軽量化）
        self.kan_layers = nn.ModuleList()
        layers = config.kan_layers
        
        for i in range(len(layers) - 1):
            self.kan_layers.append(
                ColabKANLayer(layers[i], layers[i+1], config.grid_size)
            )
        
        # Dirac演算子（簡略版）
        self.gamma_matrices = self._create_gamma_matrices()
        
        # θ-running ネットワーク（軽量化）
        self.theta_network = nn.Sequential(
            nn.Linear(4, 32),  # Colab最適化
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(32, 16),
            nn.ReLU(),
            nn.Linear(16, 1),
            nn.Sigmoid()
        )
        
        # 正規化
        self.final_norm = nn.LayerNorm(4)
    
    def _create_gamma_matrices(self):
        """簡略化ガンマ行列"""
        gamma = torch.zeros(4, 4, 4, dtype=torch.complex64)
        
        # Pauli行列ベース（簡略版）
        gamma[0] = torch.tensor([[1, 0, 0, 0], [0, 1, 0, 0], 
                                [0, 0, -1, 0], [0, 0, 0, -1]], dtype=torch.complex64)
        gamma[1] = torch.tensor([[0, 0, 0, 1], [0, 0, 1, 0], 
                                [0, -1, 0, 0], [-1, 0, 0, 0]], dtype=torch.complex64)
        gamma[2] = torch.tensor([[0, 0, 0, -1j], [0, 0, 1j, 0], 
                                [0, 1j, 0, 0], [-1j, 0, 0, 0]], dtype=torch.complex64)
        gamma[3] = torch.tensor([[0, 0, 1, 0], [0, 0, 0, -1], 
                                [-1, 0, 0, 0], [0, 1, 0, 0]], dtype=torch.complex64)
        
        return gamma.to(device)
    
    def forward(self, x, energy_scale=None):
        # KAN forward pass
        kan_output = x
        for layer in self.kan_layers:
            kan_output = layer(kan_output)
        
        kan_output = self.final_norm(kan_output)
        
        # Dirac場構築（簡略版）
        batch_size = x.size(0)
        dirac_field = kan_output.unsqueeze(-1).expand(-1, -1, 4)
        
        # 🔧 θ-parameter計算（次元安定化）
        if energy_scale is None:
            # エネルギースケールがない場合は座標のみ使用
            theta_input = x[:, :4] if x.size(-1) >= 4 else F.pad(x, (0, 4 - x.size(-1)))
        else:
            # エネルギースケールとの結合
            if energy_scale.dim() > 1:
                energy_scale = energy_scale.flatten(start_dim=1)
            
            # 座標を4次元に調整
            coords_4d = x[:, :4] if x.size(-1) >= 4 else F.pad(x, (0, 4 - x.size(-1)))
            
            # エネルギースケールを1次元に調整
            if energy_scale.size(-1) > 1:
                energy_scale = energy_scale[:, :1]  # 最初の成分のみ使用
            
            # 結合して4次元入力を作成
            theta_input = torch.cat([coords_4d[:, :3], energy_scale], dim=-1)
        
        # θネットワークの入力次元を確実に4にする
        if theta_input.size(-1) != 4:
            if theta_input.size(-1) < 4:
                theta_input = F.pad(theta_input, (0, 4 - theta_input.size(-1)))
            else:
                theta_input = theta_input[:, :4]
        
        theta = self.theta_network(theta_input) * self.config.theta_base
        
        return dirac_field, theta

# ===================================================================
# 🔬 Physics Loss (Colab最適化版)
# ===================================================================

class ColabPhysicsLoss(nn.Module):
    """Google Colab最適化 Physics Loss"""
    
    def __init__(self, config: ColabNKATConfig):
        super().__init__()
        self.config = config
    
    def spectral_dimension_loss(self, dirac_field, target_dim=4.0):
        """スペクトラル次元損失（軽量版）"""
        # 簡略化計算（Colab最適化）
        field_norm = torch.norm(dirac_field, dim=-1)
        log_field = torch.log(field_norm + 1e-8)
        
        # 近似スペクトラル次元
        spectral_dim = 4.0 + 0.1 * torch.mean(log_field)
        
        return F.mse_loss(spectral_dim, torch.tensor(target_dim, device=dirac_field.device))
    
    def jacobi_constraint_loss(self, dirac_field):
        """Jacobi制約（簡略版）"""
        # 簡略化Jacobi制約
        jacobi_term = torch.sum(dirac_field ** 2, dim=-1)
        target = torch.ones_like(jacobi_term)
        return F.mse_loss(jacobi_term, target)
    
    def connes_distance_loss(self, dirac_field, coordinates):
        """Connes距離（軽量版）"""
        # 座標差分
        coord_diff = coordinates.unsqueeze(1) - coordinates.unsqueeze(0)
        distance_matrix = torch.norm(coord_diff, dim=-1)
        
        # 簡略化Connes距離
        field_diff = dirac_field.unsqueeze(1) - dirac_field.unsqueeze(0)
        field_distance = torch.norm(field_diff, dim=-1).mean(dim=-1)
        
        # 距離制約
        connes_constraint = torch.abs(distance_matrix - field_distance)
        return torch.mean(connes_constraint)
    
    def theta_running_loss(self, theta_values, energy_scale):
        """NaN安全θ-running制約（診断結果修正版）"""
        if energy_scale is None:
            return torch.tensor(0.0, device=theta_values.device, requires_grad=True)
        
        # 🔧 次元処理（安全化）
        if energy_scale.dim() > 1:
            energy_scale = energy_scale[:, 0] if energy_scale.size(1) > 0 else energy_scale.flatten()
        
        if theta_values.dim() > 1:
            theta_values = theta_values.mean(dim=-1)
        
        # 🔧 重要修正：θ値の範囲制限（診断結果に基づく）
        # 1e-80 → 1e-50 に変更（log10で-50まで、Infinity回避）
        theta_clamped = torch.clamp(theta_values, min=1e-50, max=1e-10)
        
        # 🔧 重要修正：エネルギースケールの範囲制限
        energy_clamped = torch.clamp(energy_scale, min=1e10, max=1e18)
        
        # 安全な対数計算
        log_energy = torch.log10(energy_clamped)
        running_target = -0.1 * log_energy  # -1.8 to -1.0 範囲
        
        theta_log = torch.log10(theta_clamped)  # -50 to -10 範囲
        
        # 🔧 次元調整（安全化）
        if theta_log.shape != running_target.shape:
            min_batch = min(theta_log.size(0), running_target.size(0))
            theta_log = theta_log[:min_batch]
            running_target = running_target[:min_batch]
        
        # 🔧 重要修正：MSE計算前の最終チェック
        if torch.isinf(theta_log).any() or torch.isinf(running_target).any():
            print("⚠️ θ-running: Infinity検出 - 安全値に置換")
            theta_log = torch.where(torch.isinf(theta_log), torch.tensor(-30.0, device=theta_log.device), theta_log)
            running_target = torch.where(torch.isinf(running_target), torch.tensor(-1.5, device=running_target.device), running_target)
        
        loss = F.mse_loss(theta_log, running_target)
        
        # 🔧 最終安全チェック
        if torch.isnan(loss) or torch.isinf(loss):
            print("⚠️ θ-running MSE: NaN/Inf検出 - 安全値に設定")
            loss = torch.tensor(1.0, device=loss.device, requires_grad=True)
        
        return loss
    
    def forward(self, dirac_field, theta, coordinates, energy_scale=None):
        """統合物理損失（数値安定化版）"""
        # 🔧 NaN防止のための入力チェック
        if torch.isnan(dirac_field).any() or torch.isinf(dirac_field).any():
            print("⚠️ Dirac場にNaN/Inf検出 - クランプ処理")
            dirac_field = torch.clamp(dirac_field, -1e6, 1e6)
        
        if torch.isnan(theta).any() or torch.isinf(theta).any():
            print("⚠️ θ値にNaN/Inf検出 - クランプ処理")
            theta = torch.clamp(theta, 1e-80, 1e-10)
        
        spectral_loss = self.spectral_dimension_loss(dirac_field, self.config.target_spectral_dim)
        jacobi_loss = self.jacobi_constraint_loss(dirac_field) 
        connes_loss = self.connes_distance_loss(dirac_field, coordinates)
        theta_running_loss = self.theta_running_loss(theta, energy_scale)
        
        # 🔧 各損失のNaN/Infチェック
        losses = {
            'spectral_dim': spectral_loss,
            'jacobi': jacobi_loss,
            'connes': connes_loss,
            'theta_running': theta_running_loss
        }
        
        # NaN/Inf検出と修正
        for name, loss in losses.items():
            if torch.isnan(loss).any() or torch.isinf(loss).any():
                print(f"⚠️ {name}損失にNaN/Inf検出 - 0に置換")
                losses[name] = torch.tensor(0.0, device=loss.device, requires_grad=True)
        
        total_loss = (
            self.config.weight_spectral_dim * losses['spectral_dim'] +
            self.config.weight_jacobi * losses['jacobi'] +
            self.config.weight_connes * losses['connes'] +
            self.config.weight_running * losses['theta_running']
        )
        
        # 🔧 総損失の最終チェック
        if torch.isnan(total_loss).any() or torch.isinf(total_loss).any():
            print("⚠️ 総損失にNaN/Inf検出 - 安全値に設定")
            total_loss = torch.tensor(1.0, device=total_loss.device, requires_grad=True)
        
        losses['total'] = total_loss
        return losses

# ===================================================================
# 🔧 Colab Optuna Objective
# ===================================================================

def plot_colab_results(history, config, save_path=None):
    """Google Colab結果可視化"""
    
    plt.style.use('seaborn-v0_8')
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    fig.suptitle('🌐 Google Colab NKAT最適化結果', fontsize=16, fontweight='bold')
    
    epochs = range(1, len(history['total_loss']) + 1)
    
    # 損失推移
    axes[0, 0].plot(epochs, history['total_loss'], 'b-', linewidth=2, label='総損失')
    axes[0, 0].set_title('📉 損失推移')
    axes[0, 0].set_xlabel('エポック')
    axes[0, 0].set_ylabel('損失')
    axes[0, 0].grid(True, alpha=0.3)
    axes[0, 0].legend()
    
    # スペクトラル次元
    axes[0, 1].plot(epochs, history['spectral_dim_estimates'], 'r-', linewidth=2, label='スペクトラル次元')
    axes[0, 1].axhline(y=config.target_spectral_dim, color='g', linestyle='--', 
                      label=f'目標値 ({config.target_spectral_dim})')
    axes[0, 1].set_title('🎯 スペクトラル次元収束')
    axes[0, 1].set_xlabel('エポック')
    axes[0, 1].set_ylabel('スペクトラル次元')
    axes[0, 1].grid(True, alpha=0.3)
    axes[0, 1].legend()
    
    # θ値推移
    axes[1, 0].semilogy(epochs, history['theta_values'], 'g-', linewidth=2, label='θ値')
    axes[1, 0].set_title('🔄 θ-parameter推移')
    axes[1, 0].set_xlabel('エポック')
    axes[1, 0].set_ylabel('θ値 (log scale)')
    axes[1, 0].grid(True, alpha=0.3)
    axes[1, 0].legend()
    
    # GPU使用量
    if history['gpu_memory']:
        axes[1, 1].plot(epochs, history['gpu_memory'], 'm-', linewidth=2, label='GPU使用量')
        axes[1, 1].set_title('💾 GPU メモリ使用量')
        axes[1, 1].set_xlabel('エポック')
        axes[1, 1].set_ylabel('メモリ (GB)')
        axes[1, 1].grid(True, alpha=0.3)
        axes[1, 1].legend()
    else:
        axes[1, 1].text(0.5, 0.5, 'GPU情報なし', ha='center', va='center', 
                       transform=axes[1, 1].transAxes, fontsize=14)
        axes[1, 1].set_title('💾 GPU メモリ使用量')
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"📊 結果グラフ保存: {save_path}")
        
        # Google Driveにも保存
        if IN_COLAB:
            drive_path = '/content/drive/MyDrive/NKAT_Research/results.png'
            plt.savefig(drive_path, dpi=300, bbox_inches='tight')
            print(f"☁️ Google Drive保存: {drive_path}")
    
    plt.show()

# ===================================================================
# 🌐 Google Colab専用簡単実行関数
# ===================================================================

def quick_install_and_run():
    """
    Google Colab専用クイックスタート関数
    パッケージインストールから実行まで一括処理
    """
    
    print("🚀 NKAT Google Colab クイックスタート")
    print("=" * 60)
    
    # 必須パッケージの強制インストール
    print("📦 必須パッケージインストール中...")
    
    packages_to_install = [
        'optuna',
        'psutil', 
        'rich',
        'seaborn'
    ]
    
    for package in packages_to_install:
        print(f"   インストール中: {package}")
        os.system(f"pip install {package} -q --upgrade")
    
    print("✅ パッケージインストール完了")
    
    # 環境再読み込み
    print("🔄 環境再読み込み中...")
    
    # 基本実行
    print("🚀 NKAT最適化開始...")
    try:
        return run_nkat_colab(epochs=50, trials=10, use_optuna=True)
    except Exception as e:
        print(f"❌ エラー発生: {e}")
        print("🔄 Optuna無しで再試行...")
        return run_nkat_colab(epochs=50, trials=0, use_optuna=False)

def run_nkat_colab(epochs=100, batch_size=16, grid_size=32, trials=15, use_optuna=True, resume=False):
    """
    Google Colab専用簡単実行関数
    
    Args:
        epochs (int): エポック数
        batch_size (int): バッチサイズ
        grid_size (int): KANグリッドサイズ
        trials (int): Optuna試行回数
        use_optuna (bool): Optuna最適化を使用するか
        resume (bool): チェックポイントから再開するか
    
    Example:
        # 基本実行
        run_nkat_colab()
        
        # カスタム設定
        run_nkat_colab(epochs=50, grid_size=48, trials=10, use_optuna=False)
        
        # レジューム実行
        run_nkat_colab(resume=True, epochs=200)
        
        # クイックスタート（推奨）
        quick_install_and_run()
    """
    
    print("🌐 NKAT Google Colab 簡単実行モード")
    
    # Google Colab環境設定
    setup_colab_environment()
    
    # Optuna無効時の自動調整
    if use_optuna and not OPTUNA_AVAILABLE:
        print("⚠️ Optuna未使用 - 最適化を無効にして継続")
        use_optuna = False
    
    # 設定作成
    config = ColabNKATConfig()
    config.num_epochs = epochs
    config.batch_size = batch_size
    config.grid_size = grid_size  # グリッドサイズ反映
    config.n_trials = trials
    config.resume_from_checkpoint = resume
    config.save_to_drive = True  # Colabでは常にDrive保存
    
    print("=" * 80)
    print("🌐 NKAT Google Colab Optimization (簡単実行)")
    print("=" * 80)
    print(f"🔧 設定:")
    print(f"   エポック: {epochs}")
    print(f"   バッチサイズ: {batch_size}")
    print(f"   グリッドサイズ: {grid_size}")
    print(f"   Optuna試行: {trials}回")
    print(f"   Optuna使用: {'ON' if use_optuna else 'OFF'}")
    print(f"   レジューム: {'ON' if resume else 'OFF'}")
    
    try:
        # 訓練実行
        model, history, convergence_achieved, checkpoint_path = train_colab_nkat_safe(
            config, use_optuna=use_optuna
        )
        
        # 結果可視化
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        plot_path = f"nkat_colab_results_{timestamp}.png"
        plot_colab_results(history, config, plot_path)
        
        # 結果サマリー
        print("\n" + "=" * 80)
        print("🎊 Google Colab NKAT最適化完了")
        print("=" * 80)
        print(f"📊 最終結果:")
        print(f"   最終損失: {history['total_loss'][-1]:.6f}")
        print(f"   スペクトラル次元: {history['spectral_dim_estimates'][-1]:.6f}")
        print(f"   θ値: {history['theta_values'][-1]:.2e}")
        print(f"   収束達成: {'✅' if convergence_achieved else '❌'}")
        
        # 継続推奨
        if not convergence_achieved:
            print("\n🔄 学習継続推奨:")
            print("   run_nkat_colab(resume=True, epochs=200)")
        else:
            print("\n🎊 最適化成功！理論物理学的検証準備完了")
        
        # Colab専用ダウンロード
        if IN_COLAB:
            print("\n📥 結果ダウンロード:")
            try:
                files.download(plot_path)
                if checkpoint_path:
                    files.download(checkpoint_path)
                print("✅ ファイルダウンロード完了")
            except Exception as e:
                print(f"⚠️ ダウンロードエラー: {e}")
                print("💡 Google Driveから手動でダウンロードしてください")
        
        return model, history, convergence_achieved
        
    except Exception as e:
        print(f"❌ エラー発生: {str(e)}")
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            print("🧹 GPUメモリクリーンアップ完了")
        return None, None, False

# ===================================================================
# 🎯 Early Stopping & Advanced Logging
# ===================================================================

class EarlyStopping:
    """Early Stopping with patience"""
    
    def __init__(self, patience=10, min_delta=1e-6, restore_best_weights=True):
        self.patience = patience
        self.min_delta = min_delta
        self.restore_best_weights = restore_best_weights
        self.best_loss = float('inf')
        self.counter = 0
        self.best_weights = None
        
    def __call__(self, val_loss, model):
        if val_loss < self.best_loss - self.min_delta:
            self.best_loss = val_loss
            self.counter = 0
            if self.restore_best_weights:
                self.best_weights = model.state_dict().copy()
        else:
            self.counter += 1
            
        if self.counter >= self.patience:
            if self.restore_best_weights and self.best_weights:
                model.load_state_dict(self.best_weights)
            return True
        return False

class AdvancedLogger:
    """詳細ロギングシステム"""
    
    def __init__(self, config: ColabNKATConfig):
        self.config = config
        self.log_file = f"nkat_training_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        self.metrics_history = {
            'epoch': [],
            'total_loss': [],
            'spectral_dim_loss': [],
            'jacobi_loss': [],
            'connes_loss': [],
            'theta_running_loss': [],
            'learning_rate': [],
            'gpu_memory_mb': [],
            'training_time_sec': []
        }
        
    def log(self, message, level="INFO"):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] {level}: {message}"
        print(log_entry)
        
        if self.config.detailed_logging:
            with open(self.log_file, 'a', encoding='utf-8') as f:
                f.write(log_entry + '\n')
    
    def log_epoch(self, epoch, losses, lr, gpu_memory, training_time):
        self.metrics_history['epoch'].append(epoch)
        self.metrics_history['total_loss'].append(losses['total'].item())
        self.metrics_history['spectral_dim_loss'].append(losses['spectral_dim'].item())
        self.metrics_history['jacobi_loss'].append(losses['jacobi'].item())
        self.metrics_history['connes_loss'].append(losses['connes'].item())
        self.metrics_history['theta_running_loss'].append(losses['theta_running'].item())
        self.metrics_history['learning_rate'].append(lr)
        self.metrics_history['gpu_memory_mb'].append(gpu_memory)
        self.metrics_history['training_time_sec'].append(training_time)
        
        if self.config.detailed_logging:
            self.log(f"Epoch {epoch}: Loss={losses['total'].item():.6f}, "
                    f"SpectralDim={losses['spectral_dim'].item():.6f}, "
                    f"LR={lr:.2e}, GPU={gpu_memory:.1f}MB, Time={training_time:.1f}s")
    
    def save_metrics(self):
        metrics_file = f"nkat_metrics_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(metrics_file, 'w', encoding='utf-8') as f:
            json.dump(self.metrics_history, f, indent=2, ensure_ascii=False)
        self.log(f"メトリクス保存: {metrics_file}")
        return metrics_file

# ===================================================================
# 🚀 Extended Long-term Training Function
# ===================================================================

def run_extended_nkat_training(
    epochs=100, 
    grid_size=48, 
    trials=20, 
    use_mixed_precision=True,
    early_stopping=True,
    detailed_logging=True,
    resume=False
):
    """
    🚀 拡張NKAT長期訓練システム
    
    Args:
        epochs (int): 最大エポック数
        grid_size (int): KANグリッドサイズ (32, 48, 64)
        trials (int): Optuna試行回数
        use_mixed_precision (bool): 混合精度使用
        early_stopping (bool): Early Stopping使用
        detailed_logging (bool): 詳細ログ出力
        resume (bool): チェックポイントから再開
    
    Returns:
        model, history, convergence_achieved, metrics_file
    """
    
    print("🚀 NKAT拡張長期訓練システム開始")
    print("=" * 80)
    
    # 拡張設定
    config = ColabNKATConfig()
    config.num_epochs = epochs
    config.grid_size = grid_size
    config.n_trials = trials
    config.use_mixed_precision = use_mixed_precision
    config.early_stopping_patience = 10 if early_stopping else 0
    config.detailed_logging = detailed_logging
    config.resume_from_checkpoint = resume
    config.checkpoint_dir = "./nkat_extended_checkpoints"
    
    print(f"🔧 拡張設定:")
    print(f"   最大エポック: {epochs}")
    print(f"   グリッドサイズ: {grid_size}⁴")
    print(f"   Optuna試行: {trials}回")
    print(f"   混合精度: {'ON' if use_mixed_precision else 'OFF'}")
    print(f"   Early Stopping: {'ON' if early_stopping else 'OFF'}")
    print(f"   詳細ログ: {'ON' if detailed_logging else 'OFF'}")
    
    # 詳細ロガー初期化
    logger = AdvancedLogger(config)
    logger.log("🚀 拡張NKAT訓練開始")
    
    # Early Stopping初期化
    early_stopper = None
    if early_stopping:
        early_stopper = EarlyStopping(
            patience=config.early_stopping_patience,
            min_delta=config.early_stopping_min_delta
        )
        logger.log(f"🎯 Early Stopping設定: patience={config.early_stopping_patience}")
    
    try:
        # メイン訓練実行
        logger.log("🔍 Optuna最適化開始")
        model, history, convergence_achieved, checkpoint_path = train_colab_nkat_safe(
            config, use_optuna=True
        )
        
        # 拡張訓練ループ（Early Stopping対応）
        if not convergence_achieved and early_stopper:
            logger.log("🔄 拡張訓練ループ開始（Early Stopping監視）")
            
            # 追加エポック実行
            additional_epochs = max(0, epochs - len(history['total_loss']))
            if additional_epochs > 0:
                logger.log(f"📈 追加{additional_epochs}エポック実行")
                
                # 継続訓練のロジックをここに実装
                # （簡略化のため、現在は基本訓練のみ）
        
        # メトリクス保存
        metrics_file = logger.save_metrics()
        
        # 結果可視化（拡張版）
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        plot_path = f"nkat_extended_results_{timestamp}.png"
        plot_colab_results(history, config, plot_path)
        
        # 最終レポート
        logger.log("=" * 60)
        logger.log("🎊 拡張NKAT訓練完了")
        logger.log("=" * 60)
        logger.log(f"📊 最終結果:")
        logger.log(f"   最終損失: {history['total_loss'][-1]:.8f}")
        logger.log(f"   スペクトラル次元: {history['spectral_dim_estimates'][-1]:.8f}")
        logger.log(f"   θ値: {history['theta_values'][-1]:.2e}")
        logger.log(f"   収束達成: {'✅' if convergence_achieved else '❌'}")
        logger.log(f"   チェックポイント: {checkpoint_path}")
        logger.log(f"   メトリクス: {metrics_file}")
        
        # 物理的意義の評価
        spectral_error = abs(history['spectral_dim_estimates'][-1] - config.target_spectral_dim)
        if spectral_error < 1e-4:
            logger.log("🌟 理論物理学的に極めて高精度な収束を達成！")
        elif spectral_error < 1e-3:
            logger.log("✨ 理論物理学的に十分な精度で収束")
        else:
            logger.log("🔄 さらなる最適化が推奨されます")
        
        return model, history, convergence_achieved, metrics_file
        
    except Exception as e:
        logger.log(f"❌ 拡張訓練エラー: {str(e)}", "ERROR")
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            logger.log("🧹 GPUメモリクリーンアップ完了")
        return None, None, False, None

# ===================================================================
# 🌌 High-Dimensional Extension Preparation
# ===================================================================

def prepare_higher_dimensions(target_dim=6):
    """高次元拡張の準備"""
    print(f"🌌 {target_dim}次元拡張準備中...")
    
    # 高次元設定
    config = ColabNKATConfig()
    config.enable_higher_dimensions = True
    config.max_dimensions = target_dim
    config.kan_layers = [target_dim, 512, 256, 128, target_dim]  # 高次元対応
    
    print(f"✅ {target_dim}次元設定完了")
    return config

def prepare_kappa_minkowski():
    """κ-Minkowski変形の準備"""
    print("🔄 κ-Minkowski変形モード準備中...")
    
    config = ColabNKATConfig()
    config.kappa_minkowski_mode = True
    
    print("✅ κ-Minkowski変形設定完了")
    return config

# ===================================================================
# 🎮 Main Function
# ===================================================================

def main():
    """メイン実行関数"""
    
    # Google Colab環境設定
    setup_colab_environment()
    
    # 🔧 Google Colab対応：Jupyterカーネル引数を除外
    import sys
    filtered_args = []
    skip_next = False
    
    for i, arg in enumerate(sys.argv):
        if skip_next:
            skip_next = False
            continue
        if arg == '-f' and i + 1 < len(sys.argv):
            skip_next = True  # -f の次の引数もスキップ
            continue
        if arg.startswith('-f='):
            continue  # -f=filename 形式もスキップ
        filtered_args.append(arg)
    
    # 一時的にsys.argvを置き換え
    original_argv = sys.argv
    sys.argv = filtered_args
    
    try:
        # コマンドライン引数
        parser = argparse.ArgumentParser(description='🌐 NKAT Google Colab最適化')
        parser.add_argument('--epochs', type=int, default=100, help='エポック数')
        parser.add_argument('--batch-size', type=int, default=16, help='バッチサイズ')
        parser.add_argument('--trials', type=int, default=15, help='Optuna試行回数')
        parser.add_argument('--grid-size', type=int, default=32, help='KANグリッドサイズ')
        parser.add_argument('--no-optuna', action='store_true', help='Optuna最適化をスキップ')
        parser.add_argument('--resume', action='store_true', help='チェックポイントから再開')
        parser.add_argument('--save-drive', action='store_true', default=True, help='Google Driveに保存')
        parser.add_argument('--extended', action='store_true', help='🚀 拡張長期訓練システム使用')
        parser.add_argument('--mixed-precision', action='store_true', default=True, help='混合精度使用')
        parser.add_argument('--early-stopping', action='store_true', default=True, help='Early Stopping使用')
        parser.add_argument('--detailed-logging', action='store_true', default=True, help='詳細ログ出力')
        
        # Google Colab環境では引数なしでデフォルト実行
        if IN_COLAB and len(filtered_args) == 1:
            # Colabではデフォルト設定で実行
            args = argparse.Namespace(
                epochs=100,
                batch_size=16,
                trials=15,
                no_optuna=False,
                resume=False,
                save_drive=True,
                extended=False,
                mixed_precision=True,
                early_stopping=True,
                detailed_logging=True
            )
            print("🌐 Google Colab: デフォルト設定で実行")
        else:
            args = parser.parse_args()
        
    finally:
        # sys.argvを元に戻す
        sys.argv = original_argv
    
    # 設定作成
    config = ColabNKATConfig()
    config.num_epochs = args.epochs
    config.batch_size = args.batch_size
    config.grid_size = args.grid_size  # グリッドサイズ反映
    config.n_trials = args.trials
    config.resume_from_checkpoint = args.resume
    config.save_to_drive = args.save_drive
    
    print("=" * 80)
    print("🌐 NKAT Google Colab Optimization")
    print("=" * 80)
    print(f"🔧 Colab設定:")
    print(f"   レジューム: {'ON' if args.resume else 'OFF'}")
    print(f"   エポック: {args.epochs}")
    print(f"   バッチサイズ: {args.batch_size}")
    print(f"   グリッドサイズ: {args.grid_size}")
    print(f"   Optuna試行: {args.trials}回")
    print(f"   Google Drive保存: {'ON' if args.save_drive else 'OFF'}")
    print(f"   🚀 拡張システム: {'ON' if args.extended else 'OFF'}")
    
    # 🚀 拡張長期訓練システム分岐
    if args.extended:
        print("\n🚀 拡張長期訓練システムを開始します...")
        try:
            model, history, convergence_achieved, metrics_file = run_extended_nkat_training(
                epochs=args.epochs,
                grid_size=args.grid_size,
                trials=args.trials,
                use_mixed_precision=args.mixed_precision,
                early_stopping=args.early_stopping,
                detailed_logging=args.detailed_logging,
                resume=args.resume
            )
            
            if convergence_achieved:
                print("\n🎊 拡張訓練成功！理論物理学的検証準備完了")
            else:
                print("\n🔄 継続訓練推奨")
                
            return
            
        except Exception as e:
            print(f"❌ 拡張訓練エラー: {str(e)}")
            print("🔄 標準システムにフォールバック...")
    
    # 標準訓練システム（既存コード）
    try:
        # 訓練実行
        model, history, convergence_achieved, checkpoint_path = train_colab_nkat_safe(
            config, use_optuna=not args.no_optuna
        )
        
        # 結果可視化
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        plot_path = f"nkat_colab_results_{timestamp}.png"
        plot_colab_results(history, config, plot_path)
        
        # 結果サマリー
        print("\n" + "=" * 80)
        print("🎊 Google Colab NKAT最適化完了")
        print("=" * 80)
        print(f"📊 最終結果:")
        print(f"   最終損失: {history['total_loss'][-1]:.6f}")
        print(f"   スペクトラル次元: {history['spectral_dim_estimates'][-1]:.6f}")
        print(f"   θ値: {history['theta_values'][-1]:.2e}")
        print(f"   収束達成: {'✅' if convergence_achieved else '❌'}")
        print(f"   チェックポイント: {checkpoint_path}")
        
        # 継続推奨
        if not convergence_achieved:
            print("\n🔄 学習継続推奨:")
            print(f"   python {os.path.basename(__file__)} --resume --epochs 200")
        else:
            print("\n🎊 最適化成功！理論物理学的検証準備完了")
        
        # Colab専用ダウンロード
        if IN_COLAB:
            print("\n📥 結果ダウンロード:")
            try:
                files.download(plot_path)
                if checkpoint_path:
                    files.download(checkpoint_path)
                print("✅ ファイルダウンロード完了")
            except Exception as e:
                print(f"⚠️ ダウンロードエラー: {e}")
                print("💡 Google Driveから手動でダウンロードしてください")
            
    except Exception as e:
        print(f"❌ エラー発生: {str(e)}")
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            print("🧹 GPUメモリクリーンアップ完了")
    
    print("\n🌐 Google Colab NKAT最適化終了！")

if __name__ == "__main__":
    main() 

# ===================================================================
# 🔋 Power Failure Recovery System
# ===================================================================

import signal
import atexit
import threading
from pathlib import Path

class PowerFailureRecoverySystem:
    """電源断・システムクラッシュ対応リカバリーシステム"""
    
    def __init__(self, config: ColabNKATConfig):
        self.config = config
        self.recovery_dir = Path("./nkat_recovery")
        self.recovery_dir.mkdir(exist_ok=True)
        
        # リカバリーファイルパス
        self.state_file = self.recovery_dir / "training_state.json"
        self.model_file = self.recovery_dir / "model_emergency.pth"
        self.progress_file = self.recovery_dir / "progress_log.txt"
        self.lock_file = self.recovery_dir / "training.lock"
        
        # 自動保存スレッド
        self.auto_save_thread = None
        self.auto_save_active = False
        self.current_model = None
        self.current_optimizer = None
        self.current_scheduler = None
        self.current_epoch = 0
        self.current_history = {}
        
        # シグナルハンドラー登録
        self.setup_signal_handlers()
        
        # 終了時処理登録
        atexit.register(self.emergency_cleanup)
        
        print("🔋 電源断リカバリーシステム初期化完了")
    
    def setup_signal_handlers(self):
        """シグナルハンドラー設定"""
        try:
            # Windows/Linux対応
            if hasattr(signal, 'SIGTERM'):
                signal.signal(signal.SIGTERM, self.signal_handler)
            if hasattr(signal, 'SIGINT'):
                signal.signal(signal.SIGINT, self.signal_handler)
            if hasattr(signal, 'SIGHUP'):
                signal.signal(signal.SIGHUP, self.signal_handler)
        except Exception as e:
            print(f"⚠️ シグナルハンドラー設定警告: {e}")
    
    def signal_handler(self, signum, frame):
        """緊急終了シグナル処理"""
        print(f"\n🚨 緊急終了シグナル受信: {signum}")
        self.emergency_save()
        print("💾 緊急保存完了")
        exit(0)
    
    def start_training_session(self, model, optimizer, scheduler, history):
        """訓練セッション開始"""
        self.current_model = model
        self.current_optimizer = optimizer
        self.current_scheduler = scheduler
        self.current_history = history
        
        # 訓練ロックファイル作成
        with open(self.lock_file, 'w') as f:
            f.write(f"Training started: {datetime.now().isoformat()}\n")
            f.write(f"PID: {os.getpid()}\n")
        
        # 自動保存スレッド開始
        self.start_auto_save()
        
        print("🔋 訓練セッション開始 - リカバリー監視有効")
    
    def start_auto_save(self):
        """自動保存スレッド開始"""
        if self.auto_save_thread and self.auto_save_thread.is_alive():
            return
        
        self.auto_save_active = True
        self.auto_save_thread = threading.Thread(target=self.auto_save_loop, daemon=True)
        self.auto_save_thread.start()
        print("🔄 自動保存スレッド開始")
    
    def auto_save_loop(self):
        """自動保存ループ（バックグラウンド）"""
        while self.auto_save_active:
            try:
                time.sleep(60)  # 1分間隔
                if self.current_model is not None:
                    self.save_training_state()
            except Exception as e:
                print(f"⚠️ 自動保存エラー: {e}")
    
    def save_training_state(self):
        """訓練状態保存"""
        try:
            # 状態情報保存
            state_data = {
                'timestamp': datetime.now().isoformat(),
                'epoch': self.current_epoch,
                'config': self.config.__dict__,
                'history': self.current_history,
                'model_file': str(self.model_file),
                'recovery_available': True
            }
            
            with open(self.state_file, 'w', encoding='utf-8') as f:
                json.dump(state_data, f, indent=2, ensure_ascii=False)
            
            # モデル状態保存
            if self.current_model:
                checkpoint_data = {
                    'epoch': self.current_epoch,
                    'model_state_dict': self.current_model.state_dict(),
                    'optimizer_state_dict': self.current_optimizer.state_dict() if self.current_optimizer else None,
                    'scheduler_state_dict': self.current_scheduler.state_dict() if self.current_scheduler else None,
                    'history': self.current_history,
                    'timestamp': datetime.now().isoformat(),
                    'recovery_save': True
                }
                torch.save(checkpoint_data, self.model_file)
            
            # 進捗ログ更新
            with open(self.progress_file, 'a', encoding='utf-8') as f:
                f.write(f"[{datetime.now().isoformat()}] Epoch {self.current_epoch} - Auto-saved\n")
                
        except Exception as e:
            print(f"⚠️ 状態保存エラー: {e}")
    
    def emergency_save(self):
        """緊急保存"""
        print("🚨 緊急保存実行中...")
        try:
            self.save_training_state()
            
            # 緊急保存マーカー
            emergency_file = self.recovery_dir / "emergency_save.marker"
            with open(emergency_file, 'w') as f:
                f.write(f"Emergency save: {datetime.now().isoformat()}\n")
                f.write(f"Epoch: {self.current_epoch}\n")
                
            print("✅ 緊急保存完了")
        except Exception as e:
            print(f"❌ 緊急保存失敗: {e}")
    
    def check_recovery_available(self):
        """リカバリー可能性チェック"""
        if not self.state_file.exists():
            return False, "状態ファイルなし"
        
        if not self.model_file.exists():
            return False, "モデルファイルなし"
        
        try:
            with open(self.state_file, 'r', encoding='utf-8') as f:
                state_data = json.load(f)
            
            if not state_data.get('recovery_available', False):
                return False, "リカバリー無効"
            
            return True, f"エポック {state_data['epoch']} から復元可能"
            
        except Exception as e:
            return False, f"状態ファイル読み込みエラー: {e}"
    
    def recover_training_state(self):
        """訓練状態復元"""
        available, message = self.check_recovery_available()
        if not available:
            raise RuntimeError(f"リカバリー不可: {message}")
        
        print(f"🔄 訓練状態復元中: {message}")
        
        # 状態データ読み込み
        with open(self.state_file, 'r', encoding='utf-8') as f:
            state_data = json.load(f)
        
        # モデルデータ読み込み
        checkpoint_data = torch.load(self.model_file, map_location=device)
        
        print(f"✅ エポック {state_data['epoch']} から復元完了")
        return state_data, checkpoint_data
    
    def update_epoch(self, epoch):
        """エポック更新"""
        self.current_epoch = epoch
    
    def update_history(self, history):
        """履歴更新"""
        self.current_history = history
    
    def stop_auto_save(self):
        """自動保存停止"""
        self.auto_save_active = False
        if self.auto_save_thread:
            self.auto_save_thread.join(timeout=5)
        print("🔄 自動保存停止")
    
    def emergency_cleanup(self):
        """終了時クリーンアップ"""
        try:
            self.stop_auto_save()
            if self.lock_file.exists():
                self.lock_file.unlink()
        except Exception as e:
            print(f"⚠️ クリーンアップエラー: {e}")

# ===================================================================
# 🚀 Recovery-Enhanced Extended Training
# ===================================================================

def run_extended_nkat_with_recovery(
    epochs=100, 
    grid_size=48, 
    trials=20, 
    use_mixed_precision=True,
    early_stopping=True,
    detailed_logging=True,
    resume=True  # デフォルトでリカバリー有効
):
    """
    🔋 電源断対応拡張NKAT訓練システム
    """
    
    print("🔋 電源断対応NKAT訓練システム開始")
    print("=" * 80)
    
    # 拡張設定
    config = ColabNKATConfig()
    config.num_epochs = epochs
    config.grid_size = grid_size
    config.n_trials = trials
    config.use_mixed_precision = use_mixed_precision
    config.early_stopping_patience = 10 if early_stopping else 0
    config.detailed_logging = detailed_logging
    config.resume_from_checkpoint = resume
    config.checkpoint_dir = "./nkat_extended_checkpoints"
    
    # リカバリーシステム初期化
    recovery_system = PowerFailureRecoverySystem(config)
    
    # 既存の訓練状態チェック
    available, message = recovery_system.check_recovery_available()
    
    if available and resume:
        print(f"🔄 リカバリー可能: {message}")
        response = input("リカバリーしますか？ (y/n): ").lower().strip()
        if response == 'y':
            try:
                state_data, checkpoint_data = recovery_system.recover_training_state()
                print(f"✅ エポック {checkpoint_data['epoch']} から復元")
                
                # 復元された設定で継続
                config.num_epochs = max(epochs, checkpoint_data['epoch'] + 10)
                
            except Exception as e:
                print(f"⚠️ リカバリー失敗: {e}")
                print("🔄 新規訓練を開始")
    
    print(f"🔧 電源断対応設定:")
    print(f"   最大エポック: {epochs}")
    print(f"   グリッドサイズ: {grid_size}⁴")
    print(f"   自動保存: 1分間隔")
    print(f"   緊急保存: シグナル対応")
    print(f"   リカバリー: {'ON' if resume else 'OFF'}")
    
    try:
        # 拡張訓練実行
        return run_extended_nkat_training(
            epochs=epochs,
            grid_size=grid_size,
            trials=trials,
            use_mixed_precision=use_mixed_precision,
            early_stopping=early_stopping,
            detailed_logging=detailed_logging,
            resume=resume
        )
    
    except KeyboardInterrupt:
        print("\n🚨 Ctrl+C検出 - 緊急保存実行")
        recovery_system.emergency_save()
        print("💾 緊急保存完了 - 安全に終了")
        return None, None, False, None
    
    except Exception as e:
        print(f"❌ 訓練エラー: {e}")
        recovery_system.emergency_save()
        print("💾 エラー時緊急保存完了")
        raise
    
    finally:
        recovery_system.stop_auto_save()
        recovery_system.emergency_cleanup()

# ===================================================================
# 🛡️ NaN Complete Elimination System
# ===================================================================

import torch.nn.utils as nn_utils

class NaNGuardian:
    """NaN完全撲滅システム"""
    
    def __init__(self, model, max_grad_norm=1.0, enable_anomaly_detection=False):
        self.model = model
        self.max_grad_norm = max_grad_norm
        self.nan_count = 0
        self.inf_count = 0
        
        # 異常検出モード（デバッグ用）
        if enable_anomaly_detection:
            torch.autograd.set_detect_anomaly(True)
            print("🔍 異常検出モード有効")
        else:
            torch.autograd.set_detect_anomaly(False)
    
    def sanitize_tensor(self, tensor, name="tensor"):
        """テンソルの数値安定化"""
        if tensor is None:
            return tensor
            
        # NaN/Inf検出
        nan_mask = torch.isnan(tensor)
        inf_mask = torch.isinf(tensor)
        
        if nan_mask.any():
            self.nan_count += nan_mask.sum().item()
            print(f"⚠️ {name}にNaN検出: {nan_mask.sum().item()}個")
        
        if inf_mask.any():
            self.inf_count += inf_mask.sum().item()
            print(f"⚠️ {name}にInf検出: {inf_mask.sum().item()}個")
        
        # 安全化処理
        tensor = torch.nan_to_num(tensor, nan=0.0, posinf=1e6, neginf=-1e6)
        
        # 極値クランプ
        tensor = torch.clamp(tensor, -1e8, 1e8)
        
        return tensor
    
    def sanitize_model_parameters(self):
        """モデルパラメータの安全化"""
        with torch.no_grad():
            for name, param in self.model.named_parameters():
                if param.grad is not None:
                    param.grad = self.sanitize_tensor(param.grad, f"grad_{name}")
                param.data = self.sanitize_tensor(param.data, f"param_{name}")
    
    def clip_gradients(self):
        """勾配クリッピング"""
        if self.max_grad_norm > 0:
            grad_norm = nn_utils.clip_grad_norm_(
                self.model.parameters(), 
                self.max_grad_norm
            )
            return grad_norm.item() if isinstance(grad_norm, torch.Tensor) else grad_norm
        return 0.0
    
    def get_stats(self):
        """統計情報取得"""
        return {
            'nan_count': self.nan_count,
            'inf_count': self.inf_count,
            'total_anomalies': self.nan_count + self.inf_count
        }
    
    def reset_stats(self):
        """統計リセット"""
        self.nan_count = 0
        self.inf_count = 0

# ===================================================================
# 🔧 Enhanced Physics Loss (NaN-Safe)
# ===================================================================

class NaNSafePhysicsLoss(nn.Module):
    """NaN安全版物理損失関数"""
    
    def __init__(self, config: ColabNKATConfig):
        super().__init__()
        self.config = config
        self.guardian = None  # 後で設定
        self.eps = 1e-12  # 数値安定化定数
    
    def set_guardian(self, guardian):
        """NaNガーディアン設定"""
        self.guardian = guardian
    
    def safe_log(self, x, min_val=1e-12):
        """安全な対数計算"""
        x_safe = torch.clamp(x, min=min_val)
        return torch.log(x_safe)
    
    def safe_sqrt(self, x, min_val=1e-12):
        """安全な平方根計算"""
        x_safe = torch.clamp(x, min=min_val)
        return torch.sqrt(x_safe)
    
    def safe_div(self, numerator, denominator, eps=1e-12):
        """安全な除算"""
        denominator_safe = torch.clamp(torch.abs(denominator), min=eps)
        return numerator / denominator_safe
    
    def spectral_dimension_loss(self, dirac_field, target_dim=4.0):
        """NaN安全スペクトラル次元損失"""
        # 安全な正規化
        field_norm = torch.norm(dirac_field, dim=-1) + self.eps
        log_field = self.safe_log(field_norm)
        
        # 安定化されたスペクトラル次元計算
        spectral_dim = 4.0 + 0.1 * torch.mean(log_field)
        
        # NaN/Infチェック
        if self.guardian:
            spectral_dim = self.guardian.sanitize_tensor(spectral_dim, "spectral_dim")
        
        target_tensor = torch.tensor(target_dim, device=dirac_field.device, dtype=dirac_field.dtype)
        loss = F.mse_loss(spectral_dim, target_tensor)
        
        return self.guardian.sanitize_tensor(loss, "spectral_loss") if self.guardian else loss
    
    def jacobi_constraint_loss(self, dirac_field):
        """NaN安全Jacobi制約"""
        jacobi_term = torch.sum(dirac_field ** 2, dim=-1) + self.eps
        target = torch.ones_like(jacobi_term)
        
        loss = F.mse_loss(jacobi_term, target)
        return self.guardian.sanitize_tensor(loss, "jacobi_loss") if self.guardian else loss
    
    def connes_distance_loss(self, dirac_field, coordinates):
        """NaN安全Connes距離"""
        batch_size = coordinates.size(0)
        if batch_size < 2:
            return torch.tensor(0.0, device=coordinates.device, requires_grad=True)
        
        # 座標差分（安全化）
        coord_diff = coordinates.unsqueeze(1) - coordinates.unsqueeze(0)
        distance_matrix = torch.norm(coord_diff, dim=-1) + self.eps
        
        # 場の差分（安全化）
        field_diff = dirac_field.unsqueeze(1) - dirac_field.unsqueeze(0)
        field_distance = torch.norm(field_diff, dim=-1).mean(dim=-1) + self.eps
        
        # 安全な距離制約
        connes_constraint = torch.abs(distance_matrix - field_distance)
        loss = torch.mean(connes_constraint)
        
        return self.guardian.sanitize_tensor(loss, "connes_loss") if self.guardian else loss
    
    def theta_running_loss(self, theta_values, energy_scale):
        """NaN安全θ-running制約"""
        if energy_scale is None:
            return torch.tensor(0.0, device=theta_values.device, requires_grad=True)
        
        # 次元処理（安全化）
        if energy_scale.dim() > 1:
            energy_scale = energy_scale[:, 0] if energy_scale.size(1) > 0 else energy_scale.flatten()
        
        if theta_values.dim() > 1:
            theta_values = theta_values.mean(dim=-1)
        
        # エネルギースケールの対数
        log_energy = self.safe_log(torch.clamp(energy_scale, min=1e-15))
        running_target = -0.1 * log_energy
        
        theta_log = self.safe_log(torch.clamp(theta_values, min=1e-80))
        
        # 次元調整（安全化）
        if theta_log.shape != running_target.shape:
            min_batch = min(theta_log.size(0), running_target.size(0))
            theta_log = theta_log[:min_batch]
            running_target = running_target[:min_batch]
        
        loss = F.mse_loss(theta_log, running_target)
        return self.guardian.sanitize_tensor(loss, "theta_running_loss") if self.guardian else loss
    
    def forward(self, dirac_field, theta, coordinates, energy_scale=None):
        """NaN安全統合物理損失"""
        # 入力の事前安全化
        if self.guardian:
            dirac_field = self.guardian.sanitize_tensor(dirac_field, "dirac_field")
            theta = self.guardian.sanitize_tensor(theta, "theta")
            coordinates = self.guardian.sanitize_tensor(coordinates, "coordinates")
            if energy_scale is not None:
                energy_scale = self.guardian.sanitize_tensor(energy_scale, "energy_scale")
        
        # 各損失計算
        spectral_loss = self.spectral_dimension_loss(dirac_field, self.config.target_spectral_dim)
        jacobi_loss = self.jacobi_constraint_loss(dirac_field)
        connes_loss = self.connes_distance_loss(dirac_field, coordinates)
        theta_running_loss = self.theta_running_loss(theta, energy_scale)
        
        # 損失辞書
        losses = {
            'spectral_dim': spectral_loss,
            'jacobi': jacobi_loss,
            'connes': connes_loss,
            'theta_running': theta_running_loss
        }
        
        # 各損失の最終安全化
        if self.guardian:
            for name, loss in losses.items():
                losses[name] = self.guardian.sanitize_tensor(loss, f"final_{name}")
        
        # 総損失計算
        total_loss = (
            self.config.weight_spectral_dim * losses['spectral_dim'] +
            self.config.weight_jacobi * losses['jacobi'] +
            self.config.weight_connes * losses['connes'] +
            self.config.weight_running * losses['theta_running']
        )
        
        # 総損失の最終安全化
        if self.guardian:
            total_loss = self.guardian.sanitize_tensor(total_loss, "total_loss")
        
        losses['total'] = total_loss
        return losses

# ===================================================================
# 🚀 Long-term Training System (NaN-Safe)
# ===================================================================

def train_colab_nkat_safe(config: ColabNKATConfig, use_optuna: bool = True):
    """NaN安全版Google Colab NKAT training"""
    
    print("🛡️ NaN安全版 Google Colab NKAT最適化開始")
    print(f"🔥 設定: バッチ{config.batch_size}, エポック{config.num_epochs}")
    print(f"🔧 Optuna: {config.n_trials}回試行, {config.optuna_timeout}秒制限")
    
    # チェックポイント管理
    checkpoint_manager = ColabCheckpointManager(config)
    
    # レジューム処理
    start_epoch = 0
    best_loss = float('inf')
    history = {
        'total_loss': [],
        'spectral_dim_estimates': [],
        'theta_values': [],
        'gpu_memory': [],
        'learning_rates': [],
        'nan_stats': []
    }
    
    if config.resume_from_checkpoint:
        checkpoint_data = checkpoint_manager.load_latest_checkpoint()
        if checkpoint_data:
            start_epoch = checkpoint_data['epoch'] + 1
            best_loss = checkpoint_data.get('best_loss', float('inf'))
            history = checkpoint_data.get('history', history)
            print(f"🔄 エポック {start_epoch} から再開")
    
    # Optuna最適化（簡略版）
    if use_optuna and start_epoch == 0 and OPTUNA_AVAILABLE:
        print("\n🔍 Optuna最適化開始（NaN安全版）")
        # 簡略化されたOptuna処理
        config.learning_rate = 0.0001607  # 前回の最適値
        config.weight_spectral_dim = 11.5
        config.weight_running = 3.45
        config.batch_size = 20
        print("✅ 最適パラメータ適用完了")
    
    # メインモデル訓練
    print(f"\n🚀 NaN安全メイン訓練開始 (エポック {start_epoch}-{config.num_epochs})")
    
    model = ColabNKATModel(config).to(device)
    
    # 🛡️ NaN Guardian初期化
    nan_guardian = NaNGuardian(model, max_grad_norm=1.0, enable_anomaly_detection=False)
    
    # 🔧 NaN安全版物理損失関数
    criterion = NaNSafePhysicsLoss(config)
    criterion.set_guardian(nan_guardian)
    
    optimizer = AdamW(model.parameters(), lr=config.learning_rate, weight_decay=1e-5)
    scheduler = CosineAnnealingLR(optimizer, T_max=config.num_epochs)
    
    # チェックポイントからの復元
    if config.resume_from_checkpoint and 'checkpoint_data' in locals():
        model.load_state_dict(checkpoint_data['model_state_dict'])
        optimizer.load_state_dict(checkpoint_data['optimizer_state_dict'])
        if checkpoint_data['scheduler_state_dict']:
            scheduler.load_state_dict(checkpoint_data['scheduler_state_dict'])
    
    # 訓練データ生成（拡張版）
    num_samples = 2000  # 長期訓練用に増量
    train_coords = torch.randn(num_samples, 4, device=device) * np.pi
    energy_scales = torch.logspace(10, 18, num_samples, device=device).unsqueeze(1)
    
    # 訓練ループ
    model.train()
    convergence_achieved = False
    patience_counter = 0
    best_spectral_loss = float('inf')
    
    # プログレスバー
    epoch_pbar = tqdm(range(start_epoch, config.num_epochs), 
                     desc="🛡️ NaN安全NKAT訓練", 
                     bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]")
    
    for epoch in epoch_pbar:
        epoch_start_time = time.time()
        total_loss = 0
        spectral_dim_sum = 0
        theta_sum = 0
        batch_count = 0
        
        # NaN統計リセット
        nan_guardian.reset_stats()
        
        # バッチループ
        for i in range(0, num_samples, config.batch_size):
            batch_coords = train_coords[i:i+config.batch_size]
            batch_energy = energy_scales[i:i+config.batch_size]
            
            optimizer.zero_grad()
            
            try:
                if scaler and config.use_mixed_precision:
                    with torch.amp.autocast('cuda'):
                        dirac_field, theta = model(batch_coords, batch_energy)
                        losses = criterion(dirac_field, theta, batch_coords, batch_energy)
                    
                    scaler.scale(losses['total']).backward()
                    
                    # 🛡️ NaN安全処理
                    nan_guardian.sanitize_model_parameters()
                    grad_norm = nan_guardian.clip_gradients()
                    
                    scaler.step(optimizer)
                    scaler.update()
                else:
                    dirac_field, theta = model(batch_coords, batch_energy)
                    losses = criterion(dirac_field, theta, batch_coords, batch_energy)
                    losses['total'].backward()
                    
                    # 🛡️ NaN安全処理
                    nan_guardian.sanitize_model_parameters()
                    grad_norm = nan_guardian.clip_gradients()
                    
                    optimizer.step()
                
                # 統計更新（NaN安全）
                total_loss += losses['total'].item() if not torch.isnan(losses['total']) else 0.0
                spectral_dim_sum += losses['spectral_dim'].item() if not torch.isnan(losses['spectral_dim']) else 0.0
                theta_sum += theta.mean().item() if not torch.isnan(theta.mean()) else 0.0
                batch_count += 1
                
            except Exception as e:
                print(f"⚠️ バッチ処理エラー: {str(e)[:100]}...")
                continue
        
        scheduler.step()
        
        # エポック統計
        avg_loss = total_loss / max(batch_count, 1)
        avg_spectral_dim = spectral_dim_sum / max(batch_count, 1)
        avg_theta = theta_sum / max(batch_count, 1)
        current_lr = optimizer.param_groups[0]['lr']
        
        # GPU メモリ監視
        gpu_memory = 0
        if torch.cuda.is_available():
            gpu_memory = torch.cuda.memory_allocated() / 1e9
        
        # NaN統計取得
        nan_stats = nan_guardian.get_stats()
        
        # 履歴更新
        history['total_loss'].append(avg_loss)
        history['spectral_dim_estimates'].append(avg_spectral_dim)
        history['theta_values'].append(avg_theta)
        history['gpu_memory'].append(gpu_memory)
        history['learning_rates'].append(current_lr)
        history['nan_stats'].append(nan_stats)
        
        # プログレスバー更新
        epoch_pbar.set_postfix({
            'Loss': f"{avg_loss:.4f}",
            'SpectralDim': f"{avg_spectral_dim:.6f}",
            'NaN': f"{nan_stats['total_anomalies']}",
            'GPU': f"{gpu_memory:.2f}GB"
        })
        
        # 詳細レポート
        if (epoch + 1) % config.progress_update_freq == 0:
            epoch_time = time.time() - epoch_start_time
            print(f"\n📊 エポック {epoch+1}/{config.num_epochs} 詳細:")
            print(f"   損失: {avg_loss:.8f}")
            print(f"   スペクトラル次元: {avg_spectral_dim:.8f}")
            print(f"   θ値: {avg_theta:.2e}")
            print(f"   NaN検出: {nan_stats['nan_count']}個")
            print(f"   Inf検出: {nan_stats['inf_count']}個")
            print(f"   GPU使用量: {gpu_memory:.2f}GB")
            print(f"   学習率: {current_lr:.2e}")
            print(f"   エポック時間: {epoch_time:.1f}秒")
        
        # 🎯 改良された収束チェック
        if avg_spectral_dim < config.spectral_dim_tolerance:
            if avg_spectral_dim < best_spectral_loss:
                best_spectral_loss = avg_spectral_dim
                patience_counter = 0
                print(f"\n🎯 新記録！スペクトラル次元: {avg_spectral_dim:.8f}")
            else:
                patience_counter += 1
                
            if patience_counter >= 3:  # 3エポック連続で改善なしなら収束
                print(f"\n🎊 収束達成！最終スペクトラル次元: {best_spectral_loss:.8f}")
                convergence_achieved = True
                break
        else:
            patience_counter = 0
        
        # Early Stopping（長期訓練用）
        if config.early_stopping_patience > 0 and epoch > 10:
            if len(history['spectral_dim_estimates']) >= config.early_stopping_patience:
                recent_losses = history['spectral_dim_estimates'][-config.early_stopping_patience:]
                if all(abs(recent_losses[i] - recent_losses[i-1]) < config.early_stopping_min_delta 
                      for i in range(1, len(recent_losses))):
                    print(f"\n⏹️ Early Stopping: {config.early_stopping_patience}エポック改善なし")
                    break
        
        # チェックポイント保存
        if (epoch + 1) % config.checkpoint_freq == 0:
            checkpoint_manager.save_checkpoint(
                epoch, model, optimizer, scheduler, history, config,
                best_loss=min(history['total_loss']) if history['total_loss'] else float('inf')
            )
        
        # 緊急保存チェック
        if checkpoint_manager.should_emergency_save():
            checkpoint_manager.save_checkpoint(
                epoch, model, optimizer, scheduler, history, config,
                is_emergency=True, 
                best_loss=min(history['total_loss']) if history['total_loss'] else float('inf')
            )
    
    # 最終保存
    final_checkpoint = checkpoint_manager.save_checkpoint(
        epoch, model, optimizer, scheduler, history, config,
        best_loss=min(history['total_loss']) if history['total_loss'] else float('inf')
    )
    
    # 最終NaN統計レポート
    total_nan_stats = {
        'total_nan_detected': sum(stats['nan_count'] for stats in history['nan_stats']),
        'total_inf_detected': sum(stats['inf_count'] for stats in history['nan_stats']),
        'epochs_with_anomalies': sum(1 for stats in history['nan_stats'] if stats['total_anomalies'] > 0)
    }
    
    print(f"\n🛡️ NaN安全統計:")
    print(f"   総NaN検出: {total_nan_stats['total_nan_detected']}個")
    print(f"   総Inf検出: {total_nan_stats['total_inf_detected']}個")
    print(f"   異常エポック: {total_nan_stats['epochs_with_anomalies']}/{len(history['nan_stats'])}")
    
    return model, history, convergence_achieved, final_checkpoint

# 互換性のためのエイリアス
train_colab_nkat = train_colab_nkat_safe

# ===================================================================
# 💾 Colab Checkpoint Manager (Restored)
# ===================================================================

class ColabCheckpointManager:
    """Google Colab専用チェックポイント管理（復元版）"""
    
    def __init__(self, config: ColabNKATConfig):
        self.config = config
        self.checkpoint_dir = config.checkpoint_dir
        os.makedirs(self.checkpoint_dir, exist_ok=True)
        self.last_emergency_save = time.time()
        
        # Google Drive保存パス
        if IN_COLAB and config.save_to_drive:
            self.drive_dir = '/content/drive/MyDrive/NKAT_Research/checkpoints'
            os.makedirs(self.drive_dir, exist_ok=True)
        else:
            self.drive_dir = None
    
    def save_checkpoint(self, epoch, model, optimizer, scheduler, history, config, 
                       is_emergency=False, best_loss=None):
        """チェックポイント保存（Colab最適化）"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        if is_emergency:
            filename = f"colab_emergency_epoch_{epoch}_{timestamp}.pth"
        else:
            filename = f"colab_checkpoint_epoch_{epoch}_{timestamp}.pth"
            
        checkpoint_path = os.path.join(self.checkpoint_dir, filename)
        
        checkpoint_data = {
            'epoch': epoch,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'scheduler_state_dict': scheduler.state_dict() if scheduler else None,
            'config': config,
            'history': history,
            'timestamp': timestamp,
            'best_loss': best_loss,
            'random_state': torch.get_rng_state(),
            'cuda_random_state': torch.cuda.get_rng_state() if torch.cuda.is_available() else None,
            'colab_session': True
        }
        
        try:
            torch.save(checkpoint_data, checkpoint_path)
            
            # Google Driveにもバックアップ
            if self.drive_dir:
                drive_path = os.path.join(self.drive_dir, filename)
                torch.save(checkpoint_data, drive_path)
                print(f"☁️ Google Driveバックアップ: {filename}")
            
            # メタデータ保存
            meta_path = os.path.join(self.checkpoint_dir, "latest_checkpoint.json")
            meta_data = {
                'latest_checkpoint': checkpoint_path,
                'epoch': epoch,
                'timestamp': timestamp,
                'spectral_dim': history['spectral_dim_estimates'][-1] if history['spectral_dim_estimates'] else None,
                'total_loss': history['total_loss'][-1] if history['total_loss'] else None,
                'colab_session': True
            }
            
            with open(meta_path, 'w', encoding='utf-8') as f:
                json.dump(meta_data, f, indent=2, ensure_ascii=False)
                
            print(f"💾 チェックポイント保存: {os.path.basename(checkpoint_path)}")
            return checkpoint_path
            
        except Exception as e:
            print(f"⚠️ チェックポイント保存失敗: {str(e)}")
            return None
    
    def load_latest_checkpoint(self):
        """最新チェックポイント読み込み"""
        meta_path = os.path.join(self.checkpoint_dir, "latest_checkpoint.json")
        
        if not os.path.exists(meta_path):
            # Google Driveからも探す
            if self.drive_dir:
                drive_meta = os.path.join(self.drive_dir, "latest_checkpoint.json")
                if os.path.exists(drive_meta):
                    meta_path = drive_meta
                else:
                    return None
            else:
                return None
            
        try:
            with open(meta_path, 'r', encoding='utf-8') as f:
                meta_data = json.load(f)
                
            checkpoint_path = meta_data['latest_checkpoint']
            
            # ローカルにない場合はGoogle Driveから
            if not os.path.exists(checkpoint_path) and self.drive_dir:
                filename = os.path.basename(checkpoint_path)
                drive_checkpoint = os.path.join(self.drive_dir, filename)
                if os.path.exists(drive_checkpoint):
                    checkpoint_path = drive_checkpoint
                    print("☁️ Google Driveからチェックポイント読み込み")
                else:
                    print(f"⚠️ チェックポイントファイルが見つかりません")
                    return None
            
            checkpoint_data = torch.load(checkpoint_path, map_location=device)
            print(f"📂 チェックポイント読み込み: エポック {checkpoint_data['epoch']}")
            
            return checkpoint_data
            
        except Exception as e:
            print(f"⚠️ チェックポイント読み込み失敗: {str(e)}")
            return None
    
    def should_emergency_save(self):
        """緊急保存チェック（Colab頻繁保存）"""
        if not self.config.auto_backup:
            return False
            
        current_time = time.time()
        elapsed_minutes = (current_time - self.last_emergency_save) / 60
        
        if elapsed_minutes >= self.config.emergency_save_interval:
            self.last_emergency_save = current_time
            return True
            
        return False